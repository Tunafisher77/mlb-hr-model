/**
 * Daily MLB HR Picks Emailer
 *
 * Use this in the Google Sheet named:
 * Daily MLB HR Picks Scorecard
 *
 * SETUP:
 * 1. Open the Google Sheet.
 * 2. Extensions → Apps Script.
 * 3. Paste this entire script into Code.gs.
 * 4. Change RECIPIENT_EMAIL if needed.
 * 5. Run installDaily8amEmailTrigger() one time.
 * 6. Approve permissions.
 *
 * This emails the latest picks already written to the "Daily Picks" tab.
 * It does not run the Python/Colab model by itself.
 */

const RECIPIENT_EMAIL = 'matt@blvd.vegas';
const DAILY_PICKS_SHEET = 'Daily Picks';
const SUMMARY_SHEET = 'Scorecard Summary';
const TIMEZONE = 'America/Los_Angeles';

function installDaily8amEmailTrigger() {
  // Remove old duplicate triggers for this function.
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(t => {
    if (t.getHandlerFunction() === 'sendDailyMlbHrPicksEmail') {
      ScriptApp.deleteTrigger(t);
    }
  });

  ScriptApp.newTrigger('sendDailyMlbHrPicksEmail')
    .timeBased()
    .everyDays(1)
    .atHour(8)
    .nearMinute(0)
    .inTimezone(TIMEZONE)
    .create();

  Logger.log('Installed daily 8:00 AM email trigger.');
}

function sendDailyMlbHrPicksEmail() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(DAILY_PICKS_SHEET);

  if (!sheet) {
    MailApp.sendEmail({
      to: RECIPIENT_EMAIL,
      subject: 'Daily MLB HR Picks — Error',
      body: 'Could not find the Daily Picks tab.'
    });
    return;
  }

  const values = sheet.getDataRange().getValues();
  if (values.length < 2) {
    MailApp.sendEmail({
      to: RECIPIENT_EMAIL,
      subject: 'Daily MLB HR Picks — No Picks Found',
      body: 'The Daily Picks tab is empty.'
    });
    return;
  }

  const headers = values[0].map(h => String(h).trim());
  const rows = values.slice(1);

  const col = name => headers.indexOf(name);

  const dateCol = col('Date');
  const tierCol = col('Tier');
  const playerCol = col('Player');
  const teamCol = col('Team');
  const opponentCol = col('Opponent');
  const pitcherCol = col('Opposing Pitcher');
  const venueCol = col('Venue');
  const scoreCol = col('Score');
  const pvCol = col('PitcherVulnerability');
  const parkCol = col('ParkFactor');
  const weatherCol = col('WeatherScore');

  if (dateCol === -1 || playerCol === -1) {
    MailApp.sendEmail({
      to: RECIPIENT_EMAIL,
      subject: 'Daily MLB HR Picks — Error',
      body: 'Daily Picks tab is missing required columns Date and/or Player.'
    });
    return;
  }

  // Find latest date in the sheet.
  const dates = rows
    .map(r => String(r[dateCol]).trim())
    .filter(Boolean)
    .sort();

  if (!dates.length) {
    MailApp.sendEmail({
      to: RECIPIENT_EMAIL,
      subject: 'Daily MLB HR Picks — No Date Found',
      body: 'No dated picks were found in Daily Picks.'
    });
    return;
  }

  const latestDate = dates[dates.length - 1];

  const latestRows = rows.filter(r => String(r[dateCol]).trim() === latestDate);

  const primary = [];
  const secondary = [];
  const longshot = [];

  latestRows.forEach(r => {
    const tier = tierCol >= 0 ? String(r[tierCol]).trim() : '';
    const rankText = headers.indexOf('Rank') >= 0 ? String(r[headers.indexOf('Rank')]).trim() : '';
    let finalTier = tier;

    if (!finalTier && rankText) {
      const rank = Number(rankText);
      if (rank <= 3) finalTier = 'Primary';
      else if (rank <= 6) finalTier = 'Secondary';
      else if (rank <= 9) finalTier = 'Longshot';
    }

    const line = formatPickLine(r, {
      playerCol,
      teamCol,
      opponentCol,
      pitcherCol,
      scoreCol,
      venueCol,
      pvCol,
      parkCol,
      weatherCol
    });

    if (finalTier === 'Primary') primary.push(line);
    else if (finalTier === 'Secondary') secondary.push(line);
    else if (finalTier === 'Longshot') longshot.push(line);
  });

  const subject = `Daily MLB HR Picks — ${latestDate}`;

  const plainBody = buildPlainTextEmail({
    latestDate,
    primary,
    secondary,
    longshot,
    spreadsheetUrl: ss.getUrl()
  });

  const htmlBody = buildHtmlEmail({
    latestDate,
    primary,
    secondary,
    longshot,
    spreadsheetUrl: ss.getUrl()
  });

  MailApp.sendEmail({
    to: RECIPIENT_EMAIL,
    subject,
    body: plainBody,
    htmlBody
  });
}

function formatPickLine(row, idx) {
  const get = i => i >= 0 ? row[i] : '';

  const player = get(idx.playerCol);
  const team = get(idx.teamCol);
  const opponent = get(idx.opponentCol);
  const pitcher = get(idx.pitcherCol);
  const score = get(idx.scoreCol);
  const venue = get(idx.venueCol);
  const pv = get(idx.pvCol);
  const park = get(idx.parkCol);
  const weather = get(idx.weatherCol);

  let line = `${player}`;
  if (team) line += ` (${team})`;
  if (pitcher) line += ` vs ${pitcher}`;
  if (score !== '') line += ` — Score ${roundDisplay(score)}`;

  const details = [];
  if (opponent) details.push(`Opp: ${opponent}`);
  if (venue) details.push(`Venue: ${venue}`);
  if (pv !== '') details.push(`PitcherVuln: ${roundDisplay(pv)}`);
  if (park !== '') details.push(`Park: ${roundDisplay(park)}`);
  if (weather !== '') details.push(`Weather: ${roundDisplay(weather)}`);

  if (details.length) line += ` (${details.join(' | ')})`;

  return line;
}

function roundDisplay(value) {
  const n = Number(value);
  if (isNaN(n)) return value;
  return Math.round(n * 10) / 10;
}

function buildPlainTextEmail(data) {
  return [
    `⚾ Daily HR Card — ${data.latestDate}`,
    '',
    '🔥 Primary',
    ...(data.primary.length ? data.primary.map(x => `- ${x}`) : ['- No primary picks found']),
    '',
    '🎯 Secondary',
    ...(data.secondary.length ? data.secondary.map(x => `- ${x}`) : ['- No secondary picks found']),
    '',
    '💰 Longshot',
    ...(data.longshot.length ? data.longshot.map(x => `- ${x}`) : ['- No longshot picks found']),
    '',
    'Google Sheet:',
    data.spreadsheetUrl,
    '',
    'Reminder: These are model picks, not guarantees.'
  ].join('\n');
}

function buildHtmlEmail(data) {
  const section = (title, rows) => {
    const items = rows.length
      ? rows.map(x => `<li>${escapeHtml(x)}</li>`).join('')
      : '<li>No picks found</li>';
    return `<h3>${title}</h3><ul>${items}</ul>`;
  };

  return `
    <div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.45;">
      <h2>⚾ Daily HR Card — ${escapeHtml(data.latestDate)}</h2>
      ${section('🔥 Primary', data.primary)}
      ${section('🎯 Secondary', data.secondary)}
      ${section('💰 Longshot', data.longshot)}
      <p><a href="${data.spreadsheetUrl}">Open Google Sheet</a></p>
      <p style="color:#777;">Reminder: These are model picks, not guarantees.</p>
    </div>
  `;
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function sendTestDailyMlbHrPicksEmail() {
  sendDailyMlbHrPicksEmail();
}
